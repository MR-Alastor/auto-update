--//Rebalance Booking statistics: by fm.venom and Arx1mag 2024


if not function_ptr then function_ptr = UpgradesTweakData._init_pd2_values end
function UpgradesTweakData:_init_pd2_values()
    function_ptr(self)   
--Костюм-двойка
	self.values.player.body_armor.armor[1] = 0
	self.values.player.body_armor.movement[1] = 1.05
	self.values.player.body_armor.concealment[1] = 30
	self.values.player.body_armor.dodge[1] = 0.05
	self.values.player.body_armor.damage_shake[1] = 1
	self.values.player.body_armor.stamina[1] = 1.025	
--Легкий баллистический жилет	
	self.values.player.body_armor.armor[2] = 3
	self.values.player.body_armor.movement[2] = 1.025
	self.values.player.body_armor.concealment[2] = 26
	self.values.player.body_armor.dodge[2] = -0.05
	self.values.player.body_armor.damage_shake[2] = 0.96
	self.values.player.body_armor.stamina[2] = 1
--Баллистический жилет
	self.values.player.body_armor.armor[3] = 4
	self.values.player.body_armor.movement[3] = 0.97
	self.values.player.body_armor.concealment[3] = 23
	self.values.player.body_armor.dodge[3] = -0.1
	self.values.player.body_armor.damage_shake[3] = 0.92
	self.values.player.body_armor.stamina[3] = 0.95
--Тяжелый баллистический жилет
	self.values.player.body_armor.armor[4] = 5
	self.values.player.body_armor.movement[4] = 0.97
	self.values.player.body_armor.concealment[4] = 21
	self.values.player.body_armor.dodge[4] = -0.15
	self.values.player.body_armor.damage_shake[4] = 0.85
	self.values.player.body_armor.stamina[4] = 0.9
--Противоосколочный жилет
	self.values.player.body_armor.armor[5] = 7
	self.values.player.body_armor.movement[5] = 0.97
	self.values.player.body_armor.concealment[5] = 18
	self.values.player.body_armor.dodge[5] = -0.2
	self.values.player.body_armor.damage_shake[5] = 0.8
	self.values.player.body_armor.stamina[5] = 0.85
--Комбинированный тактический жилет
	self.values.player.body_armor.armor[6] = 9
	self.values.player.body_armor.movement[6] = 0.97
	self.values.player.body_armor.concealment[6] = 12
	self.values.player.body_armor.dodge[6] = -0.25
	self.values.player.body_armor.damage_shake[6] = 0.7
	self.values.player.body_armor.stamina[6] = 0.8
--Улучшенный КТЖ
	self.values.player.body_armor.armor[7] = 15
	self.values.player.body_armor.movement[7] = 0.97
	self.values.player.body_armor.concealment[7] = 1
	self.values.player.body_armor.dodge[7] = -0.55
	self.values.player.body_armor.damage_shake[7] = 0.5
	self.values.player.body_armor.stamina[7] = 0.7
	
end