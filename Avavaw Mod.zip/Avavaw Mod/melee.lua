--//Rebalance melle: by fm.venom and Arx1mag 2024


Hooks:PostHook(BlackMarketTweakData, "_init_melee_weapons", "Only Meta Melees", function(self)

--Кулаки
	self.melee_weapons.fists.stats.min_damage = 3
	self.melee_weapons.fists.stats.max_damage = 5.5
	self.melee_weapons.fists.stats.min_damage_effect = 3
	self.melee_weapons.fists.stats.max_damage_effect = 2
	self.melee_weapons.fists.stats.charge_time = 0.1
    self.melee_weapons.fists.stats.concealment = 30
	
--Боевой нож	
	self.melee_weapons.kabar.stats.min_damage = 3
	self.melee_weapons.kabar.stats.max_damage = 8
	self.melee_weapons.kabar.stats.min_damage_effect = 1
	self.melee_weapons.kabar.stats.max_damage_effect = 1
	self.melee_weapons.kabar.stats.charge_time = 0.1
	self.melee_weapons.kabar.stats.range = 185
	self.melee_weapons.kabar.repeat_expire_t = 0.6
	self.melee_weapons.kabar.expire_t = 1.2
	self.melee_weapons.kabar.melee_damage_delay = 0.1
    self.melee_weapons.kabar.stats.concealment = 30
--Какой то Рембо
	self.melee_weapons.rambo.stats.min_damage = 3
	self.melee_weapons.rambo.stats.max_damage = 8
	self.melee_weapons.rambo.stats.min_damage_effect = 1
	self.melee_weapons.rambo.stats.max_damage_effect = 1
	self.melee_weapons.rambo.repeat_expire_t = 0.5
	self.melee_weapons.rambo.expire_t = 1
	self.melee_weapons.rambo.stats.charge_time = 0.1
	self.melee_weapons.rambo.stats.range = 200
	self.melee_weapons.rambo.stats.concealment = 30
--Боевой нож Berger
	self.melee_weapons.gerber.repeat_expire_t = 0.5
	self.melee_weapons.gerber.expire_t = 1
	self.melee_weapons.gerber.stats.min_damage = 3
	self.melee_weapons.gerber.stats.max_damage = 8
	self.melee_weapons.gerber.stats.min_damage_effect = 1
	self.melee_weapons.gerber.stats.max_damage_effect = 1
	self.melee_weapons.gerber.stats.charge_time = 0.1
	self.melee_weapons.gerber.stats.range = 160
	self.melee_weapons.gerber.stats.concealment = 29
--Клинок воина	
	self.melee_weapons.kampfmesser.stats.min_damage = 3
	self.melee_weapons.kampfmesser.stats.max_damage = 8
	self.melee_weapons.kampfmesser.stats.min_damage_effect = 1
	self.melee_weapons.kampfmesser.stats.max_damage_effect = 1
	self.melee_weapons.kampfmesser.stats.charge_time = 0.1
	self.melee_weapons.kampfmesser.stats.range = 185
	self.melee_weapons.kampfmesser.stats.concealment = 30
--Кастет	
	self.melee_weapons.brass_knuckles.stats.min_damage = 3
	self.melee_weapons.brass_knuckles.stats.max_damage = 5.5
	self.melee_weapons.brass_knuckles.stats.min_damage_effect = 3
	self.melee_weapons.brass_knuckles.stats.max_damage_effect = 2
	self.melee_weapons.brass_knuckles.stats.charge_time = 0.1
	self.melee_weapons.brass_knuckles.stats.range = 150
	self.melee_weapons.brass_knuckles.stats.concealment = 30
--Тамогафк
	self.melee_weapons.tomahawk.stats.min_damage = 3
	self.melee_weapons.tomahawk.stats.max_damage = 8
	self.melee_weapons.tomahawk.stats.min_damage_effect = 1
	self.melee_weapons.tomahawk.stats.max_damage_effect = 1
	self.melee_weapons.tomahawk.stats.charge_time = 0.1
	self.melee_weapons.tomahawk.stats.range = 225
	self.melee_weapons.tomahawk.expire_t = 0.6
	self.melee_weapons.tomahawk.repeat_expire_t = 0.8
	self.melee_weapons.tomahawk.attack_allowed_expire_t = 0.1
	self.melee_weapons.tomahawk.stats.concealment = 28
--Дубинка
	self.melee_weapons.baton.stats.min_damage = 3
	self.melee_weapons.baton.stats.max_damage = 9
	self.melee_weapons.baton.stats.min_damage_effect = 5
	self.melee_weapons.baton.stats.max_damage_effect = 3
	self.melee_weapons.baton.stats.charge_time = 0.1
	self.melee_weapons.baton.stats.range = 250
	self.melee_weapons.baton.stats.concealment = 30
--Лопата
	self.melee_weapons.shovel.stats.min_damage = 2
	self.melee_weapons.shovel.stats.max_damage = 4
	self.melee_weapons.shovel.stats.min_damage_effect = 10
	self.melee_weapons.shovel.stats.max_damage_effect = 10
	self.melee_weapons.shovel.stats.charge_time = 0.1
	self.melee_weapons.shovel.stats.range = 250
	self.melee_weapons.shovel.stats.concealment = 27
--Универсальный мачете	
	self.melee_weapons.becker.stats.min_damage = 3
	self.melee_weapons.becker.stats.max_damage = 8
	self.melee_weapons.becker.stats.min_damage_effect = 1
	self.melee_weapons.becker.stats.max_damage_effect = 1
	self.melee_weapons.becker.stats.charge_time = 0.1
	self.melee_weapons.becker.stats.range = 200
	self.melee_weapons.becker.repeat_expire_t = 0.6
	self.melee_weapons.becker.stats.concealment = 27
--Пачка денег	
    self.melee_weapons.moneybundle.stats.min_damage = 3
	self.melee_weapons.moneybundle.stats.max_damage = 5.5
	self.melee_weapons.moneybundle.stats.min_damage_effect = 3
	self.melee_weapons.moneybundle.stats.max_damage_effect = 2
	self.melee_weapons.moneybundle.stats.charge_time = 0.1
	self.melee_weapons.moneybundle.stats.range = 150
	self.melee_weapons.moneybundle.repeat_expire_t = 0.5
	self.melee_weapons.moneybundle.stats.concealment = 30
--Бейсбольная бита Люсиль	
	self.melee_weapons.barbedwire.stats.min_damage = 3
	self.melee_weapons.barbedwire.stats.max_damage = 9
	self.melee_weapons.barbedwire.stats.min_damage_effect = 5
	self.melee_weapons.barbedwire.stats.max_damage_effect = 3
	self.melee_weapons.barbedwire.stats.charge_time = 0.1
	self.melee_weapons.barbedwire.stats.range = 275
	self.melee_weapons.barbedwire.repeat_expire_t = 1
	self.melee_weapons.barbedwire.expire_t = 1.2
	self.melee_weapons.barbedwire.melee_damage_delay = 0.2
	self.melee_weapons.barbedwire.stats.concealment = 27
--Нож X-46	
	self.melee_weapons.x46.stats.min_damage = 3
	self.melee_weapons.x46.stats.max_damage = 8
	self.melee_weapons.x46.stats.min_damage_effect = 1
	self.melee_weapons.x46.stats.max_damage_effect = 1
	self.melee_weapons.x46.stats.charge_time = 0.1
	self.melee_weapons.x46.stats.range = 185
	self.melee_weapons.x46.stats.concealment = 30
--Инструмент для взлома "Динь-Дон"
	self.melee_weapons.dingdong.stats.min_damage = 2
	self.melee_weapons.dingdong.stats.max_damage = 4
	self.melee_weapons.dingdong.stats.min_damage_effect = 10
	self.melee_weapons.dingdong.stats.max_damage_effect = 10
	self.melee_weapons.dingdong.stats.charge_time = 0.1
	self.melee_weapons.dingdong.stats.range = 275
	self.melee_weapons.dingdong.repeat_expire_t = 1
	self.melee_weapons.dingdong.expire_t = 1.2
	self.melee_weapons.dingdong.melee_damage_delay = 0.2
	self.melee_weapons.dingdong.stats.concealment = 26
--Ложка	
	self.melee_weapons.spoon.stats.min_damage = 4
	self.melee_weapons.spoon.stats.max_damage = 25
	self.melee_weapons.spoon.stats.min_damage_effect = 1
	self.melee_weapons.spoon.stats.max_damage_effect = 1
	self.melee_weapons.spoon.stats.charge_time = 0.1
	self.melee_weapons.spoon.stats.range = 275
	self.melee_weapons.spoon.repeat_expire_t = 1
	self.melee_weapons.spoon.expire_t = 1.2
	self.melee_weapons.spoon.melee_damage_delay = 0.2
	self.melee_weapons.spoon.stats.concealment = 26
--Ложка (Золотая)	
	self.melee_weapons.spoon_gold.stats.min_damage = 7
	self.melee_weapons.spoon_gold.stats.max_damage = 45
	self.melee_weapons.spoon_gold.stats.min_damage_effect = 1
	self.melee_weapons.spoon_gold.stats.max_damage_effect = 1
	self.melee_weapons.spoon_gold.stats.charge_time = 0.1
	self.melee_weapons.spoon_gold.stats.range = 275
	self.melee_weapons.spoon_gold.repeat_expire_t = 1
	self.melee_weapons.spoon_gold.expire_t = 1.2
	self.melee_weapons.spoon_gold.melee_damage_delay = 0.2
	self.melee_weapons.spoon_gold.stats.concealment = 27
--Штык Нож	
	self.melee_weapons.bayonet.repeat_expire_t = 0.5
	self.melee_weapons.bayonet.expire_t = 1
	self.melee_weapons.bayonet.stats.min_damage = 2
	self.melee_weapons.bayonet.stats.max_damage = 8
	self.melee_weapons.bayonet.stats.min_damage_effect = 1
	self.melee_weapons.bayonet.stats.max_damage_effect = 0.445
	self.melee_weapons.bayonet.stats.charge_time = 0.1
	self.melee_weapons.bayonet.stats.range = 185
	self.melee_weapons.bayonet.stats.concealment = 30
--Компактный топор	
	self.melee_weapons.bullseye.stats.min_damage = 3
	self.melee_weapons.bullseye.stats.max_damage = 8
	self.melee_weapons.bullseye.stats.min_damage_effect = 1
	self.melee_weapons.bullseye.stats.max_damage_effect = 1
	self.melee_weapons.bullseye.stats.charge_time = 0.1
	self.melee_weapons.bullseye.stats.range = 185
	self.melee_weapons.bullseye.stats.concealment = 29
--Бейсбольная бита	
	self.melee_weapons.baseballbat.stats.min_damage = 3
	self.melee_weapons.baseballbat.stats.max_damage = 9
	self.melee_weapons.baseballbat.stats.min_damage_effect = 5
	self.melee_weapons.baseballbat.stats.max_damage_effect = 3
	self.melee_weapons.baseballbat.stats.charge_time = 0.1
	self.melee_weapons.baseballbat.stats.range = 250
	self.melee_weapons.baseballbat.stats.concealment = 27
	self.melee_weapons.baseballbat.repeat_expire_t = 0.9
	self.melee_weapons.baseballbat.expire_t = 1.2
	self.melee_weapons.baseballbat.melee_damage_delay = 0.2
--Разделочный нож	
	self.melee_weapons.cleaver.stats.min_damage = 3
	self.melee_weapons.cleaver.stats.max_damage = 8
	self.melee_weapons.cleaver.stats.min_damage_effect = 1
	self.melee_weapons.cleaver.stats.max_damage_effect = 1
	self.melee_weapons.cleaver.stats.charge_time = 0.1
	self.melee_weapons.cleaver.stats.range = 185
	self.melee_weapons.cleaver.stats.concealment = 29
--Пожарный топор	
	self.melee_weapons.fireaxe.stats.min_damage = 7
	self.melee_weapons.fireaxe.stats.max_damage = 45
	self.melee_weapons.fireaxe.stats.min_damage_effect = 1
	self.melee_weapons.fireaxe.stats.max_damage_effect = 1
	self.melee_weapons.fireaxe.stats.charge_time = 0.1
	self.melee_weapons.fireaxe.stats.range = 275
	self.melee_weapons.fireaxe.stats.concealment = 27
	self.melee_weapons.fireaxe.repeat_expire_t = 1.6
	self.melee_weapons.fireaxe.expire_t = 1.8
	self.melee_weapons.fireaxe.melee_damage_delay = 0.6
--Мачете	
	self.melee_weapons.machete.stats.min_damage = 3
	self.melee_weapons.machete.stats.max_damage = 8
	self.melee_weapons.machete.stats.min_damage_effect = 1
	self.melee_weapons.machete.stats.max_damage_effect = 1
	self.melee_weapons.machete.stats.charge_time = 0.1
	self.melee_weapons.machete.stats.range = 225
	self.melee_weapons.machete.expire_t = 0.6
	self.melee_weapons.machete.repeat_expire_t = 0.8
	self.melee_weapons.machete.stats.concealment = 29
--Портфель	
	self.melee_weapons.briefcase.stats.min_damage = 3
	self.melee_weapons.briefcase.stats.max_damage = 5.5
	self.melee_weapons.briefcase.stats.min_damage_effect = 3
	self.melee_weapons.briefcase.stats.max_damage_effect = 2
	self.melee_weapons.briefcase.stats.charge_time = 0.1
	self.melee_weapons.briefcase.stats.range = 185
	self.melee_weapons.briefcase.stats.concealment = 30
	self.melee_weapons.briefcase.repeat_expire_t = 1
	self.melee_weapons.briefcase.expire_t = 1.2
	self.melee_weapons.briefcase.melee_damage_delay = 0.2
--Нож URSA	
	self.melee_weapons.kabartanto.stats.min_damage = 2
	self.melee_weapons.kabartanto.stats.max_damage = 8
	self.melee_weapons.kabartanto.stats.min_damage_effect = 1
	self.melee_weapons.kabartanto.stats.max_damage_effect = 1
	self.melee_weapons.kabartanto.stats.charge_time = 0.1
	self.melee_weapons.kabartanto.stats.range = 185
	self.melee_weapons.kabartanto.stats.concealment = 30
--Зубная щётка
	self.melee_weapons.toothbrush.stats.min_damage = 3
	self.melee_weapons.toothbrush.stats.max_damage = 8
	self.melee_weapons.toothbrush.stats.min_damage_effect = 1
	self.melee_weapons.toothbrush.stats.max_damage_effect = 1
	self.melee_weapons.toothbrush.stats.charge_time = 0.1
	self.melee_weapons.toothbrush.stats.range = 150
	self.melee_weapons.toothbrush.repeat_expire_t = 0.3
	self.melee_weapons.toothbrush.stats.concealment = 30
--Шеф повар
	self.melee_weapons.chef.stats.min_damage = 3
	self.melee_weapons.chef.stats.max_damage = 8
	self.melee_weapons.chef.stats.min_damage_effect = 1
	self.melee_weapons.chef.stats.max_damage_effect = 1
	self.melee_weapons.chef.stats.charge_time = 0.1
	self.melee_weapons.chef.stats.range = 150
	self.melee_weapons.chef.repeat_expire_t = 0.36
	self.melee_weapons.chef.stats.concealment = 29
--Траншейный нож
	self.melee_weapons.fairbair.stats.min_damage = 3
	self.melee_weapons.fairbair.stats.max_damage = 8
	self.melee_weapons.fairbair.stats.min_damage_effect = 1
	self.melee_weapons.fairbair.stats.max_damage_effect = 1
	self.melee_weapons.fairbair.stats.charge_time = 0.1
	self.melee_weapons.fairbair.stats.range = 175
	self.melee_weapons.fairbair.repeat_expire_t = 0.3
	self.melee_weapons.fairbair.stats.concealment = 30
--Копье свободы
	self.melee_weapons.freedom.stats.min_damage = 7
	self.melee_weapons.freedom.stats.max_damage = 45
	self.melee_weapons.freedom.stats.min_damage_effect = 1
	self.melee_weapons.freedom.stats.max_damage_effect = 1
	self.melee_weapons.freedom.stats.charge_time = 0.1
	self.melee_weapons.freedom.stats.range = 275
	self.melee_weapons.freedom.repeat_expire_t = 0.9
	self.melee_weapons.freedom.expire_t = 1.3
	self.melee_weapons.freedom.stats.concealment = 27
	self.melee_weapons.freedom.melee_damage_delay = 0.35
--Измельчитель
	self.melee_weapons.model24.stats.min_damage = 3
	self.melee_weapons.model24.stats.max_damage = 9
	self.melee_weapons.model24.stats.min_damage_effect = 5
	self.melee_weapons.model24.stats.max_damage_effect = 3
	self.melee_weapons.model24.stats.charge_time = 0.1
	self.melee_weapons.model24.stats.range = 185
	self.melee_weapons.model24.repeat_expire_t = 0.8
	self.melee_weapons.model24.stats.concealment = 28
--Чванливая палка
	self.melee_weapons.swagger.stats.min_damage = 3
	self.melee_weapons.swagger.stats.max_damage = 9
	self.melee_weapons.swagger.stats.min_damage_effect = 5
	self.melee_weapons.swagger.stats.max_damage_effect = 3
	self.melee_weapons.swagger.stats.charge_time = 0.1
	self.melee_weapons.swagger.stats.range = 225
	self.melee_weapons.swagger.repeat_expire_t = 0.8
	self.melee_weapons.swagger.stats.concealment = 28
--Alpha Молот
	self.melee_weapons.alien_maul.stats.min_damage = 2
	self.melee_weapons.alien_maul.stats.max_damage = 4
	self.melee_weapons.alien_maul.stats.min_damage_effect = 10
	self.melee_weapons.alien_maul.stats.max_damage_effect = 10
	self.melee_weapons.alien_maul.stats.charge_time = 0.1
	self.melee_weapons.alien_maul.stats.range = 375
	self.melee_weapons.alien_maul.repeat_expire_t = 1
	self.melee_weapons.alien_maul.expire_t = 1.2
	self.melee_weapons.alien_maul.melee_damage_delay = 0.2
	self.melee_weapons.alien_maul.stats.concealment = 26
--Дубинка
	self.melee_weapons.shillelagh.stats.min_damage = 3
	self.melee_weapons.shillelagh.stats.max_damage = 9
	self.melee_weapons.shillelagh.stats.min_damage_effect = 5
	self.melee_weapons.shillelagh.stats.max_damage_effect = 3
	self.melee_weapons.shillelagh.stats.charge_time = 0.1
	self.melee_weapons.shillelagh.stats.range = 185
	self.melee_weapons.shillelagh.repeat_expire_t = 0.8
	self.melee_weapons.shillelagh.stats.concealment = 27
--Боксерские перчатки
	self.melee_weapons.boxing_gloves.stats.min_damage = 3
	self.melee_weapons.boxing_gloves.stats.max_damage = 5.5
	self.melee_weapons.boxing_gloves.stats.min_damage_effect = 3
	self.melee_weapons.boxing_gloves.stats.max_damage_effect = 2
	self.melee_weapons.boxing_gloves.stats.charge_time = 0.1
	self.melee_weapons.boxing_gloves.stats.range = 150
	self.melee_weapons.boxing_gloves.stats.concealment = 30
--Нож-секач
	self.melee_weapons.meat_cleaver.stats.min_damage = 3
	self.melee_weapons.meat_cleaver.stats.max_damage = 8
	self.melee_weapons.meat_cleaver.stats.min_damage_effect = 1
	self.melee_weapons.meat_cleaver.stats.max_damage_effect = 1
	self.melee_weapons.meat_cleaver.stats.charge_time = 0.1
	self.melee_weapons.meat_cleaver.stats.range = 195
	self.melee_weapons.meat_cleaver.stats.concealment = 28	
--Молоток
	self.melee_weapons.hammer.stats.min_damage = 2
	self.melee_weapons.hammer.stats.max_damage = 4
	self.melee_weapons.hammer.stats.min_damage_effect = 10
	self.melee_weapons.hammer.stats.max_damage_effect = 10
	self.melee_weapons.hammer.stats.charge_time = 0.1
	self.melee_weapons.hammer.stats.range = 185
	self.melee_weapons.hammer.repeat_expire_t = 0.8
	self.melee_weapons.hammer.stats.concealment = 28
--Бутылка
	self.melee_weapons.whiskey.stats.min_damage = 3
	self.melee_weapons.whiskey.stats.max_damage = 5.5
	self.melee_weapons.whiskey.stats.min_damage_effect = 3
	self.melee_weapons.whiskey.stats.max_damage_effect = 2
	self.melee_weapons.whiskey.stats.charge_time = 0.1
	self.melee_weapons.whiskey.stats.range = 185
	self.melee_weapons.whiskey.repeat_expire_t = 0.8
	self.melee_weapons.whiskey.stats.concealment = 30
--Вилка
	self.melee_weapons.fork.stats.min_damage = 3
	self.melee_weapons.fork.stats.max_damage = 8
	self.melee_weapons.fork.stats.min_damage_effect = 1
	self.melee_weapons.fork.stats.max_damage_effect = 1
	self.melee_weapons.fork.stats.charge_time = 0.1
	self.melee_weapons.fork.stats.range = 185
	self.melee_weapons.fork.repeat_expire_t = 0.3
	self.melee_weapons.fork.stats.concealment = 28
--Покер (Видимо карты)
	self.melee_weapons.poker.stats.min_damage = 3
	self.melee_weapons.poker.stats.max_damage = 9
	self.melee_weapons.poker.stats.min_damage_effect = 5
	self.melee_weapons.poker.stats.max_damage_effect = 3
	self.melee_weapons.poker.stats.charge_time = 0.1
	self.melee_weapons.poker.stats.range = 185
	self.melee_weapons.poker.repeat_expire_t = 0.8
	self.melee_weapons.poker.stats.concealment = 28
--Шпатель
	self.melee_weapons.spatula.stats.min_damage = 3
	self.melee_weapons.spatula.stats.max_damage = 5.5
	self.melee_weapons.spatula.stats.min_damage_effect = 3
	self.melee_weapons.spatula.stats.max_damage_effect = 2
	self.melee_weapons.spatula.stats.charge_time = 0.1
	self.melee_weapons.spatula.stats.range = 185
	self.melee_weapons.spatula.repeat_expire_t = 0.8
	self.melee_weapons.spatula.stats.concealment = 29
--Размягчитель
	self.melee_weapons.tenderizer.stats.min_damage = 2
	self.melee_weapons.tenderizer.stats.max_damage = 4
	self.melee_weapons.tenderizer.stats.min_damage_effect = 10
	self.melee_weapons.tenderizer.stats.max_damage_effect = 10
	self.melee_weapons.tenderizer.stats.charge_time = 0.1
	self.melee_weapons.tenderizer.stats.range = 185
	self.melee_weapons.tenderizer.repeat_expire_t = 0.8
	self.melee_weapons.tenderizer.stats.concealment = 28
--Томагавк охотника
	self.melee_weapons.scalper.stats.min_damage = 3
	self.melee_weapons.scalper.stats.max_damage = 8
	self.melee_weapons.scalper.stats.min_damage_effect = 1
	self.melee_weapons.scalper.stats.max_damage_effect = 1
	self.melee_weapons.scalper.stats.charge_time = 0.1
	self.melee_weapons.scalper.stats.range = 200
	self.melee_weapons.scalper.expire_t = 0.6
	self.melee_weapons.scalper.repeat_expire_t = 0.8
	self.melee_weapons.scalper.attack_allowed_expire_t = 0.1
	self.melee_weapons.scalper.stats.concealment = 28
--Золотая лихорадка
	self.melee_weapons.mining_pick.stats.min_damage = 7
	self.melee_weapons.mining_pick.stats.max_damage = 45
	self.melee_weapons.mining_pick.stats.min_damage_effect = 1
	self.melee_weapons.mining_pick.stats.max_damage_effect = 1
	self.melee_weapons.mining_pick.stats.charge_time = 0.1
	self.melee_weapons.mining_pick.stats.range = 225
	self.melee_weapons.mining_pick.expire_t = 1.1
	self.melee_weapons.mining_pick.repeat_expire_t = 0.8
	self.melee_weapons.mining_pick.attack_allowed_expire_t = 0.1
    self.melee_weapons.mining_pick.stats.concealment = 27
--Ты мой
	self.melee_weapons.branding_iron.stats.min_damage = 3
	self.melee_weapons.branding_iron.stats.max_damage = 9
	self.melee_weapons.branding_iron.stats.min_damage_effect = 5
	self.melee_weapons.branding_iron.stats.max_damage_effect = 3
	self.melee_weapons.branding_iron.stats.charge_time = 0.1
	self.melee_weapons.branding_iron.stats.range = 225
	self.melee_weapons.branding_iron.expire_t = 1.1
	self.melee_weapons.branding_iron.repeat_expire_t = 0.8
	self.melee_weapons.branding_iron.attack_allowed_expire_t = 0.1
	self.melee_weapons.branding_iron.stats.concealment = 27
--Арканзасская зубочистка
	self.melee_weapons.bowie.stats.min_damage = 3
	self.melee_weapons.bowie.stats.max_damage = 8
	self.melee_weapons.bowie.stats.min_damage_effect = 1
	self.melee_weapons.bowie.stats.max_damage_effect = 1
	self.melee_weapons.bowie.stats.charge_time = 0.1
	self.melee_weapons.bowie.stats.range = 225
	self.melee_weapons.bowie.expire_t = 1.1
	self.melee_weapons.bowie.repeat_expire_t = 0.8
	self.melee_weapons.bowie.attack_allowed_expire_t = 0.1
	self.melee_weapons.bowie.stats.concealment = 30
--Микрофон
	self.melee_weapons.microphone.stats.min_damage = 3
	self.melee_weapons.microphone.stats.max_damage = 5.5
	self.melee_weapons.microphone.stats.min_damage_effect = 3
	self.melee_weapons.microphone.stats.max_damage_effect = 2
	self.melee_weapons.microphone.stats.charge_time = 0.1
	self.melee_weapons.microphone.stats.range = 150
	self.melee_weapons.microphone.expire_t = 1.1
	self.melee_weapons.microphone.repeat_expire_t = 0.8
	self.melee_weapons.microphone.attack_allowed_expire_t = 0.1
	self.melee_weapons.microphone.stats.concealment = 30
--Металлоискатель
	self.melee_weapons.detector.stats.min_damage = 3
	self.melee_weapons.detector.stats.max_damage = 5.5
	self.melee_weapons.detector.stats.min_damage_effect = 3
	self.melee_weapons.detector.stats.max_damage_effect = 2
	self.melee_weapons.detector.stats.charge_time = 0.1
	self.melee_weapons.detector.stats.range = 225
	self.melee_weapons.detector.expire_t = 1.1
	self.melee_weapons.detector.repeat_expire_t = 0.8
	self.melee_weapons.detector.attack_allowed_expire_t = 0.1
	self.melee_weapons.detector.stats.concealment = 29
--Подставка для микрофона
	self.melee_weapons.micstand.stats.min_damage = 3
	self.melee_weapons.micstand.stats.max_damage = 9
	self.melee_weapons.micstand.stats.min_damage_effect = 5
	self.melee_weapons.micstand.stats.max_damage_effect = 3
	self.melee_weapons.micstand.stats.charge_time = 0.1
	self.melee_weapons.micstand.stats.range = 250
	self.melee_weapons.micstand.expire_t = 0.8
	self.melee_weapons.micstand.repeat_expire_t = 0.8
	self.melee_weapons.micstand.attack_allowed_expire_t = 0.1
	self.melee_weapons.micstand.stats.concealment = 27
--Классическая дубинка
	self.melee_weapons.oldbaton.stats.min_damage = 3
	self.melee_weapons.oldbaton.stats.max_damage = 9
	self.melee_weapons.oldbaton.stats.min_damage_effect = 5
	self.melee_weapons.oldbaton.stats.max_damage_effect = 3
	self.melee_weapons.oldbaton.stats.charge_time = 0.1
	self.melee_weapons.oldbaton.stats.range = 250
	self.melee_weapons.oldbaton.expire_t = 1.1
	self.melee_weapons.oldbaton.repeat_expire_t = 0.8
	self.melee_weapons.oldbaton.attack_allowed_expire_t = 0.1
	self.melee_weapons.oldbaton.stats.concealment = 28
--Хоккейная клюшка
	self.melee_weapons.hockey.stats.min_damage = 3
	self.melee_weapons.hockey.stats.max_damage = 9
	self.melee_weapons.hockey.stats.min_damage_effect = 5
	self.melee_weapons.hockey.stats.max_damage_effect = 3
	self.melee_weapons.hockey.stats.charge_time = 0.1
	self.melee_weapons.hockey.stats.range = 250
	self.melee_weapons.hockey.expire_t = 0.8
	self.melee_weapons.hockey.repeat_expire_t = 0.8
	self.melee_weapons.hockey.attack_allowed_expire_t = 0.1
	self.melee_weapons.hockey.stats.concealment = 27
--Cкладной нож
	self.melee_weapons.switchblade.stats.min_damage = 3
	self.melee_weapons.switchblade.stats.max_damage = 8
	self.melee_weapons.switchblade.stats.min_damage_effect = 1
	self.melee_weapons.switchblade.stats.max_damage_effect = 1
	self.melee_weapons.switchblade.stats.charge_time = 0.1
	self.melee_weapons.switchblade.stats.range = 175
	self.melee_weapons.switchblade.stats.concealment = 30
	self.melee_weapons.switchblade.repeat_expire_t = 0.3
	self.melee_weapons.switchblade.expire_t = 1
	self.melee_weapons.switchblade.melee_damage_delay = 0.1
--Тайзер
	self.melee_weapons.taser.stats.min_damage = 2
	self.melee_weapons.taser.stats.max_damage = 2
	self.melee_weapons.taser.stats.min_damage_effect = 1
	self.melee_weapons.taser.stats.max_damage_effect = 1
	self.melee_weapons.taser.stats.charge_time = 0.1
	self.melee_weapons.taser.stats.range = 200
	self.melee_weapons.taser.stats.concealment = 30
	self.melee_weapons.taser.expire_t = 1
	self.melee_weapons.taser.repeat_expire_t = 0.7
	self.melee_weapons.taser.melee_damage_delay = 0.1
--Джекпот
	self.melee_weapons.slot_lever.stats.min_damage = 3
	self.melee_weapons.slot_lever.stats.max_damage = 9
	self.melee_weapons.slot_lever.stats.min_damage_effect = 5
	self.melee_weapons.slot_lever.stats.max_damage_effect = 3
	self.melee_weapons.slot_lever.stats.charge_time = 0.1
	self.melee_weapons.slot_lever.stats.range = 225
	self.melee_weapons.slot_lever.stats.concealment = 28
	self.melee_weapons.slot_lever.expire_t = 0.6
	self.melee_weapons.slot_lever.repeat_expire_t = 0.7
	self.melee_weapons.slot_lever.melee_damage_delay = 0.1
--Грабли
	self.melee_weapons.croupier_rake.stats.min_damage = 3
	self.melee_weapons.croupier_rake.stats.max_damage = 9
	self.melee_weapons.croupier_rake.stats.min_damage_effect = 5
	self.melee_weapons.croupier_rake.stats.max_damage_effect = 3
	self.melee_weapons.croupier_rake.stats.charge_time = 0.1
	self.melee_weapons.croupier_rake.stats.range = 250
	self.melee_weapons.croupier_rake.stats.concealment = 28
	self.melee_weapons.croupier_rake.expire_t = 0.6
	self.melee_weapons.croupier_rake.repeat_expire_t = 0.7
	self.melee_weapons.croupier_rake.melee_damage_delay = 0.1
--Хуй пойми что
	self.melee_weapons.fight.stats.min_damage = 3
	self.melee_weapons.fight.stats.max_damage = 5.5
	self.melee_weapons.fight.stats.min_damage_effect = 3
	self.melee_weapons.fight.stats.max_damage_effect = 2
	self.melee_weapons.fight.stats.charge_time = 0.1
	self.melee_weapons.fight.stats.range = 150
	self.melee_weapons.fight.expire_t = 1.1
	self.melee_weapons.fight.repeat_expire_t = 0.55
	self.melee_weapons.fight.melee_damage_delay = 0.1
	self.melee_weapons.fight.stats.concealment = 30
--Когти
	self.melee_weapons.tiger.stats.min_damage = 3
	self.melee_weapons.tiger.stats.max_damage = 8
	self.melee_weapons.tiger.stats.min_damage_effect = 1
	self.melee_weapons.tiger.stats.max_damage_effect = 1
	self.melee_weapons.tiger.stats.charge_time = 0.1
	self.melee_weapons.tiger.stats.range = 150
	self.melee_weapons.tiger.melee_damage_delay = 0.1
	self.melee_weapons.tiger.stats.concealment = 28
--Кунай
	self.melee_weapons.cqc.stats.min_damage = 3
	self.melee_weapons.cqc.stats.max_damage = 8
	self.melee_weapons.cqc.stats.min_damage_effect = 1
	self.melee_weapons.cqc.stats.max_damage_effect = 1
	self.melee_weapons.cqc.stats.charge_time = 0.1
	self.melee_weapons.cqc.stats.range = 150
	self.melee_weapons.cqc.repeat_expire_t = 0.3
	self.melee_weapons.cqc.stats.concealment = 30
--Сай
	self.melee_weapons.twins.stats.min_damage = 3
	self.melee_weapons.twins.stats.max_damage = 8
	self.melee_weapons.twins.stats.min_damage_effect = 1
	self.melee_weapons.twins.stats.max_damage_effect = 1
	self.melee_weapons.twins.stats.charge_time = 0.1
	self.melee_weapons.twins.stats.range = 200
	self.melee_weapons.twins.repeat_expire_t = 0.6
	self.melee_weapons.twins.stats.concealment = 29
--Катана
	self.melee_weapons.sandsteel.stats = {
		weapon_type = "sharp",
		min_damage = 7,
		max_damage = 45,
		min_damage_effect = 1,
		max_damage_effect = 1,
		charge_time = 0.1,
		range = 275,
		concealment = 27,
		remove_weapon_movement_penalty = true
	}
	self.melee_weapons.sandsteel.repeat_expire_t = 0.5
	self.melee_weapons.sandsteel.expire_t = 1
	self.melee_weapons.sandsteel.melee_damage_delay = 0.1
--Великий меч
	self.melee_weapons.great.stats = {
		weapon_type = "sharp",
		min_damage = 7,
		max_damage = 45,
		min_damage_effect = 1,
		max_damage_effect = 1,
		charge_time = 0.1,
		range = 275,
		concealment = 27,
		remove_weapon_movement_penalty = true
	}
	self.melee_weapons.great.repeat_expire_t = 1.1
	self.melee_weapons.great.expire_t = 1.5
	self.melee_weapons.great.melee_damage_delay = 0.6
--Топор (Как написал передчик Бородатый)	
	self.melee_weapons.beardy.stats = {
		weapon_type = "sharp",
		min_damage = 7,
		max_damage = 45,
		min_damage_effect = 1,
		max_damage_effect = 1,
		charge_time = 0.1,
		range = 250,
		concealment = 26,
		remove_weapon_movement_penalty = true
	}
	self.melee_weapons.beardy.repeat_expire_t = 1.1
	self.melee_weapons.beardy.expire_t = 1.5
	self.melee_weapons.beardy.melee_damage_delay = 0.6
--Защитный кожух
	self.melee_weapons.buck.stats = {
		weapon_type = "sharp",
		min_damage = 3,
		max_damage = 5.5,
		min_damage_effect = 3,
		max_damage_effect = 2,
		charge_time = 0.1,
		range = 175,
		concealment = 28,
		remove_weapon_movement_penalty = true
	}
	self.melee_weapons.buck.repeat_expire_t = 0.9
	self.melee_weapons.buck.expire_t = 1.4
	self.melee_weapons.buck.melee_damage_delay = 0.4
--Утренняя звезда
	self.melee_weapons.morning.stats = {
		weapon_type = "sharp",
		min_damage = 2,
		max_damage = 4,
		min_damage_effect = 10,
		max_damage_effect = 10,
		charge_time = 0.1,
		range = 225,
		concealment = 26,
		remove_weapon_movement_penalty = true
	}
	self.melee_weapons.morning.repeat_expire_t = 0.5
	self.melee_weapons.morning.expire_t = 1.1
	self.melee_weapons.morning.melee_damage_delay = 0.1
--Болторезы
	self.melee_weapons.cutters.stats = {
		weapon_type = "blunt",
		min_damage = 3,
		max_damage = 9,
		min_damage_effect = 5,
		max_damage_effect = 3,
		charge_time = 0.1,
		range = 275,
		concealment = 27,
		remove_weapon_movement_penalty = true
	}
	self.melee_weapons.cutters.repeat_expire_t = 0.8
	self.melee_weapons.cutters.expire_t = 1.2
	self.melee_weapons.cutters.melee_damage_delay = 0.3
--Универсальный нож
	self.melee_weapons.boxcutter.stats = {
		weapon_type = "sharp",
		min_damage = 3,
		max_damage = 8,
		min_damage_effect = 1,
		max_damage_effect = 1,
		charge_time = 0.1,
		range = 185,
		concealment = 30
	}
	self.melee_weapons.boxcutter.repeat_expire_t = 0.8
	self.melee_weapons.boxcutter.expire_t = 0.5
	self.melee_weapons.boxcutter.melee_damage_delay = 0.16
--Селфи-палка
	self.melee_weapons.selfie.stats.min_damage = 3
	self.melee_weapons.selfie.stats.max_damage = 9
	self.melee_weapons.selfie.stats.min_damage_effect = 5
	self.melee_weapons.selfie.stats.max_damage_effect = 3
	self.melee_weapons.selfie.stats.charge_time = 0.1
	self.melee_weapons.selfie.stats.range = 250
	self.melee_weapons.selfie.stats.concealment = 30
	self.melee_weapons.selfie.expire_t = 0.6
--Ледоруб
	self.melee_weapons.iceaxe.stats.min_damage = 7
	self.melee_weapons.iceaxe.stats.max_damage = 45
	self.melee_weapons.iceaxe.stats.min_damage_effect = 1
	self.melee_weapons.iceaxe.stats.max_damage_effect = 1
	self.melee_weapons.iceaxe.stats.charge_time = 0.1
	self.melee_weapons.iceaxe.stats.range = 250
	self.melee_weapons.iceaxe.stats.concealment = 30
	self.melee_weapons.iceaxe.expire_t = 0.6
--Мачете
	self.melee_weapons.gator.stats.min_damage = 3
	self.melee_weapons.gator.stats.max_damage = 8
	self.melee_weapons.gator.stats.min_damage_effect = 1
	self.melee_weapons.gator.stats.max_damage_effect = 1
	self.melee_weapons.gator.stats.charge_time = 0.1
	self.melee_weapons.gator.stats.range = 225
	self.melee_weapons.gator.expire_t = 0.6
	self.melee_weapons.gator.repeat_expire_t = 0.8
	self.melee_weapons.gator.stats.concealment = 29
--Нож дайвера
	self.melee_weapons.pugio.stats.min_damage = 3
	self.melee_weapons.pugio.stats.max_damage = 8
	self.melee_weapons.pugio.stats.min_damage_effect = 1
	self.melee_weapons.pugio.stats.max_damage_effect = 1
	self.melee_weapons.pugio.stats.charge_time = 0.1
	self.melee_weapons.pugio.stats.range = 175
	self.melee_weapons.pugio.stats.concealment = 29
	self.melee_weapons.pugio.repeat_expire_t = 0.3
	self.melee_weapons.pugio.expire_t = 1
	self.melee_weapons.pugio.melee_damage_delay = 0.1
--Ножницы
	self.melee_weapons.shawn.stats = {
		weapon_type = "sharp",
		min_damage = 3,
		max_damage = 8,
		min_damage_effect = 1,
		max_damage_effect = 1,
		charge_time = 0.1,
		range = 150,
		concealment = 29,
		remove_weapon_movement_penalty = true
	}
	self.melee_weapons.shawn.repeat_expire_t = 0.36
	self.melee_weapons.shawn.expire_t = 1.8	
--Пастушья трость
	self.melee_weapons.stick.stats = {
		weapon_type = "blunt",
		min_damage = 3,
		max_damage = 9,
		min_damage_effect = 5,
		max_damage_effect = 3,
		charge_time = 0.1,
		range = 225,
		concealment = 27,
		remove_weapon_movement_penalty = true
	}
	self.melee_weapons.stick.repeat_expire_t = 0.8
	self.melee_weapons.stick.expire_t = 1.8
	self.melee_weapons.stick.melee_damage_delay = 0.2
--Вилы
	self.melee_weapons.pitchfork.stats = {
		weapon_type = "sharp",
		min_damage = 7,
		max_damage = 45,
		min_damage_effect = 1,
		max_damage_effect = 1,
		charge_time = 0.1,
		range = 225,
		concealment = 27,
		remove_weapon_movement_penalty = true
	}
	self.melee_weapons.pitchfork.repeat_expire_t = 0.8
	self.melee_weapons.pitchfork.expire_t = 1.8
	self.melee_weapons.pitchfork.melee_damage_delay = 0.3
--Охотничий нож
	self.melee_weapons.scoutknife.stats = {
		weapon_type = "sharp",
		min_damage = 3,
		max_damage = 8,
		min_damage_effect = 1,
		max_damage_effect = 1,
		charge_time = 0.1,
		range = 150,
		concealment = 29,
		remove_weapon_movement_penalty = true
	}
	self.melee_weapons.scoutknife.repeat_expire_t = 0.36
	self.melee_weapons.scoutknife.expire_t = 1.2
--Хрен пойми что Пестик какой то
	self.melee_weapons.nin.stats = {
		weapon_type = "sharp",
		min_damage = 7,
		max_damage = 45,
		min_damage_effect = 1,
		max_damage_effect = 1,
		charge_time = 0.1,
		range = 185,
		concealment = 27,
		remove_weapon_movement_penalty = true
	}
	self.melee_weapons.nin.repeat_expire_t = 0.65
	self.melee_weapons.nin.expire_t = 1.2
	self.melee_weapons.nin.melee_damage_delay = 0.1
--Специальные ножи
	self.melee_weapons.ballistic.stats.min_damage = 3
	self.melee_weapons.ballistic.stats.max_damage = 8
	self.melee_weapons.ballistic.stats.min_damage_effect = 1
	self.melee_weapons.ballistic.stats.max_damage_effect = 1
	self.melee_weapons.ballistic.stats.charge_time = 0.1
	self.melee_weapons.ballistic.stats.range = 200
	self.melee_weapons.ballistic.repeat_expire_t = 0.6
	self.melee_weapons.ballistic.stats.concealment = 29
--Электрические кастеты
	self.melee_weapons.zeus.stats.min_damage = 2
	self.melee_weapons.zeus.stats.max_damage = 2
	self.melee_weapons.zeus.stats.min_damage_effect = 1
	self.melee_weapons.zeus.stats.max_damage_effect = 1
	self.melee_weapons.zeus.stats.charge_time = 0.1
	self.melee_weapons.zeus.stats.range = 200
	self.melee_weapons.zeus.stats.concealment = 30
--Нож-бабочка
	self.melee_weapons.wing.stats = {
		weapon_type = "sharp",
		min_damage = 3,
		max_damage = 8,
		min_damage_effect = 1,
		max_damage_effect = 1,
		charge_time = 0.1,
		range = 185,
		concealment = 30,
		remove_weapon_movement_penalty = true
	}
	self.melee_weapons.wing.repeat_expire_t = 0.85
	self.melee_weapons.wing.expire_t = 1.2
	self.melee_weapons.wing.melee_damage_delay = 0.1
--Цепной хлыст (Возможно просто цепь)
	self.melee_weapons.road.stats = {
		weapon_type = "blunt",
		min_damage = 7,
		max_damage = 45,
		min_damage_effect = 1,
		max_damage_effect = 1,
		charge_time = 0.1,
		range = 185,
		concealment = 29,
		remove_weapon_movement_penalty = true
	}
	self.melee_weapons.road.repeat_expire_t = 2
	self.melee_weapons.road.expire_t = 1.2
	self.melee_weapons.road.melee_damage_delay = 0.4
--Пиломатериал облегченный L2
	self.melee_weapons.cs.stats = {
		weapon_type = "blunt",
		min_damage = 7,
		max_damage = 45,
		min_damage_effect = 1,
		max_damage_effect = 1,
		charge_time = 0.1,
		range = 185,
		concealment = 25,
		remove_weapon_movement_penalty = true
	}
	self.melee_weapons.cs.repeat_expire_t = 2
	self.melee_weapons.cs.expire_t = 1.2
	self.melee_weapons.cs.melee_damage_delay = 0.35
--Hotline 8000x
	self.melee_weapons.brick.stats = {
		weapon_type = "blunt",
		min_damage = 3,
		max_damage = 8,
		min_damage_effect = 1,
		max_damage_effect = 1,
		charge_time = 0.1,
		range = 185,
		concealment = 30,
		remove_weapon_movement_penalty = true
	}
	self.melee_weapons.brick.repeat_expire_t = 2
	self.melee_weapons.brick.expire_t = 1.2
	self.melee_weapons.brick.melee_damage_delay = 0.06
--Крюк
	self.melee_weapons.catch.stats = {
		weapon_type = "sharp",
		min_damage = 3,
		max_damage = 8,
		min_damage_effect = 1,
		max_damage_effect = 1,
		charge_time = 0.1,
		range = 200,
		concealment = 28,
		remove_weapon_movement_penalty = true
	}
	self.melee_weapons.catch.repeat_expire_t = 0.4
	self.melee_weapons.catch.expire_t = 0.6
	self.melee_weapons.catch.melee_damage_delay = 0.11
--Резкое(Хз что это)

	self.melee_weapons.oxide.stats.min_damage = 7
	self.melee_weapons.oxide.stats.max_damage = 45
	self.melee_weapons.oxide.stats.min_damage_effect = 1
	self.melee_weapons.oxide.stats.max_damage_effect = 1
	self.melee_weapons.oxide.stats.charge_time = 0.1
	self.melee_weapons.oxide.stats.range = 225
	self.melee_weapons.oxide.expire_t = 0.6
	self.melee_weapons.oxide.repeat_expire_t = 0.8
	self.melee_weapons.oxide.stats.concealment = 29
--Ручка
	self.melee_weapons.sword.stats.min_damage = 3
	self.melee_weapons.sword.stats.max_damage = 8
	self.melee_weapons.sword.stats.min_damage_effect = 1
	self.melee_weapons.sword.stats.max_damage_effect = 1
	self.melee_weapons.sword.stats.charge_time = 0.1
	self.melee_weapons.sword.stats.range = 150
	self.melee_weapons.sword.repeat_expire_t = 0.3
	self.melee_weapons.sword.stats.concealment = 30
--Вообще в душе не ебу что за ближка инфы 0
	self.melee_weapons.agave.stats.min_damage = 7
	self.melee_weapons.agave.stats.max_damage = 45
	self.melee_weapons.agave.stats.min_damage_effect = 1
	self.melee_weapons.agave.stats.max_damage_effect = 1
	self.melee_weapons.agave.melee_damage_delay = 0.1
	self.melee_weapons.agave.stats.charge_time = 0.1
	self.melee_weapons.agave.stats.range = 225
	self.melee_weapons.agave.expire_t = 0.6
	self.melee_weapons.agave.repeat_expire_t = 0.8
	self.melee_weapons.agave.stats.concealment = 29
--Вообще в душе не ебу что за ближка инфы 0
	self.melee_weapons.happy.stats = {
		min_damage = 3,
		max_damage = 9,
		min_damage_effect = 5,
		max_damage_effect = 3,
		charge_time = 0.1,
		range = 250,
		remove_weapon_movement_penalty = true,
		weapon_type = "blunt"
	}
	self.melee_weapons.happy.repeat_expire_t = 0.6
	self.melee_weapons.happy.expire_t = 0.7
	self.melee_weapons.happy.melee_damage_delay = 0.1
	self.melee_weapons.happy.stats.concealment = 30
--Вообще в душе не ебу что за ближка инфы 0
	self.melee_weapons.push.stats.min_damage = 3
	self.melee_weapons.push.stats.max_damage = 8
	self.melee_weapons.push.stats.min_damage_effect = 1
	self.melee_weapons.push.stats.max_damage_effect = 1
	self.melee_weapons.push.stats.charge_time = 0.1
	self.melee_weapons.push.stats.range = 150
	self.melee_weapons.push.stats.concealment = 30
--Вообще в душе не ебу что за ближка инфы 0
	self.melee_weapons.grip.repeat_expire_t = 0.6
	self.melee_weapons.grip.expire_t = 0.7
	self.melee_weapons.grip.melee_damage_delay = 0.1
	self.melee_weapons.grip.stats.min_damage = 3
	self.melee_weapons.grip.stats.max_damage = 8
	self.melee_weapons.grip.stats.min_damage_effect = 1
	self.melee_weapons.grip.stats.max_damage_effect = 1
	self.melee_weapons.grip.stats.charge_time = 0.1
	self.melee_weapons.grip.stats.range = 150
	self.melee_weapons.grip.stats.concealment = 30
--Какой то сок

	self.melee_weapons.sap.stats.min_damage = 2
	self.melee_weapons.sap.stats.max_damage = 4
	self.melee_weapons.sap.stats.min_damage_effect = 10
	self.melee_weapons.sap.stats.max_damage_effect = 10
	self.melee_weapons.sap.stats.charge_time = 0.1
	self.melee_weapons.sap.stats.range = 200
	self.melee_weapons.sap.stats.concealment = 30
--Алабамская бритва
	self.melee_weapons.clean.stats = {
		weapon_type = "sharp",
		min_damage = 3,
		max_damage = 8,
		min_damage_effect = 1,
		max_damage_effect = 1,
		charge_time = 0.1,
		range = 150,
		concealment = 29,
		remove_weapon_movement_penalty = true
	}
	self.melee_weapons.clean.repeat_expire_t = 0.36
	self.melee_weapons.clean.expire_t = 0.6
--Двурукий Великий правитель
	self.melee_weapons.meter.stats = {
		weapon_type = "sharp",
		min_damage = 7,
		max_damage = 45,
		min_damage_effect = 1,
		max_damage_effect = 1,
		charge_time = 0.1,
		range = 275,
		concealment = 27,
		remove_weapon_movement_penalty = true
	}
	self.melee_weapons.meter.repeat_expire_t = 1.1
	self.melee_weapons.meter.expire_t = 1.5
	self.melee_weapons.meter.melee_damage_delay = 0.6
--Тактический фонарь
	self.melee_weapons.aziz.stats.min_damage = 3
	self.melee_weapons.aziz.stats.max_damage = 8
	self.melee_weapons.aziz.stats.min_damage_effect = 1
	self.melee_weapons.aziz.stats.max_damage_effect = 1
	self.melee_weapons.aziz.stats.charge_time = 0.1
	self.melee_weapons.aziz.stats.range = 150
	self.melee_weapons.aziz.repeat_expire_t = 0.36
	self.melee_weapons.aziz.stats.concealment = 29
--Вообще в душе не ебу что за ближка инфы 0
	self.melee_weapons.hauteur.stats = {
		weapon_type = "sharp",
		min_damage = 7,
		max_damage = 45,
		min_damage_effect = 1,
		max_damage_effect = 1,
		charge_time = 0.1,
		range = 150,
		concealment = 30,
		remove_weapon_movement_penalty = true
	}
	self.melee_weapons.hauteur.repeat_expire_t = 0.6
	self.melee_weapons.hauteur.expire_t = 1.1
	self.melee_weapons.hauteur.melee_damage_delay = 0.13
--Вообще в душе не ебу что за ближка инфы 0
	self.melee_weapons.shock.stats.min_damage = 3
	self.melee_weapons.shock.stats.max_damage = 9
	self.melee_weapons.shock.stats.min_damage_effect = 5
	self.melee_weapons.shock.stats.max_damage_effect = 3
	self.melee_weapons.shock.stats.charge_time = 0.1
	self.melee_weapons.shock.stats.range = 185
	self.melee_weapons.shock.repeat_expire_t = 0.8
	self.melee_weapons.shock.stats.concealment = 28
--Вообще в душе не ебу что за ближка инфы 0
	self.melee_weapons.fear.stats = {
		weapon_type = "sharp",
		min_damage = 3,
		max_damage = 8,
		min_damage_effect = 1,
		max_damage_effect = 1,
		charge_time = 0.1,
		range = 150,
		concealment = 30,
		remove_weapon_movement_penalty = true
	}
	self.melee_weapons.fear.repeat_expire_t = 0.65
	self.melee_weapons.fear.expire_t = 1.2
	self.melee_weapons.fear.melee_damage_delay = 0.29
--Вообще в душе не ебу что за ближка инфы 0
	self.melee_weapons.chac.stats = {
		remove_weapon_movement_penalty = true,
		min_damage = 3,
		max_damage = 5.5,
		min_damage_effect = 3,
		max_damage_effect = 2,
		charge_time = 0.1,
		range = 150,
		weapon_type = "blunt"
	}
	self.melee_weapons.chac.repeat_expire_t = 0.5
	self.melee_weapons.chac.expire_t = 1.2
	self.melee_weapons.chac.melee_damage_delay = 0.1
	self.melee_weapons.chac.stats.concealment = 30
--
	self.melee_weapons.ostry.stats = {
		weapon_type = "sharp",
		min_damage = 3,
		max_damage = 8,
		min_damage_effect = 1,
		max_damage_effect = 1,
		charge_time = 0.1,
		range = 200,
		concealment = 28,
		remove_weapon_movement_penalty = true
	}
end )