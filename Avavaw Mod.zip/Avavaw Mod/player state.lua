--//Rebalance Character Statistics: by fm.venom and Arx1mag 2024

if not _upgradeValue then _upgradeValue = PlayerManager.upgrade_value end
function PlayerManager:upgrade_value( category, upgrade, default )
	
	if category == "player" and upgrade == "pick_lock_speed_multiplier" then --Скорость отмычки
		return 0.1
	elseif category == "player" and upgrade == "alarm_pager_speed_multiplier" then --Скорость ответа пейджер
		return 0.1
	elseif category == "player" and upgrade == "corpse_dispose_speed_multiplier" then --Скорость упаковки трупов
		return 0.1
	elseif category == "player" and upgrade == "passive_health_regen" then --Пассивный реген
		return 0.04
	elseif category == "player" and upgrade == "pick_up_ammo_multiplier" then --Увеличенный процент поднятия патронов
		return 5.50
	elseif category == "player" and upgrade == "critical_hit_chance" then --Шанс Крита
		return 1.0
	elseif category == "player" and upgrade == "movement_speed_multiplier" then --Скорость передвижения
		return 1.10
	elseif category == "player" and upgrade == "stamina_multiplier" then --Выносливость
		return 5
	elseif category == "player" and upgrade == "passive_dodge_chance" then --Уворот
		return 0.55
	elseif category == "player" and upgrade == "run_dodge_chance" then --Уворот при беге
		return 0.95
	elseif category == "player" and upgrade == "damage_shake_multiplier" then --Стойкость (параметр от брони)
		return 0.5
	elseif category == "player" and upgrade == "passive_damage_multiplier" then --Урон оружия
		return 2.5
	else
		return _upgradeValue(self, category, upgrade, default)
	end
end