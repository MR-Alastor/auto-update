local data = UpgradesTweakData._init_pd2_values
function UpgradesTweakData:_init_pd2_values()
	data(self, tweak_data)

---Stoic сниженный дамаг ---
	self.values.player.damage_control_passive = {{
		80, ---DMG reduced in %.
		0.25 ---IDK, but 6.25 = 16 seconds DoT, 9 = 12 I think. XD
	}}
	
	self.values.player.damage_control_auto_shrug = {
		3
	}
	
self.values.player.damage_control_healing = {
		50
	}
---Stoic---
end