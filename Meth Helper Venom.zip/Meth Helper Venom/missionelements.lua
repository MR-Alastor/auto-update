if Network:is_client() then
	return
end

local level_id = managers.job:current_level_id()
local orig_MissionScriptElement_init = MissionScriptElement.init

function MissionScriptElement.init(self, ...)
	orig_MissionScriptElement_init(self, ...)
	
	if level_id then
		if (level_id == "rat" or level_id == "alex_1") and self._id == 101123 then
			self._values.on_executed = {
				[1] = {
					["id"] = 100726,
					["delay"] = 0
				}
			}
		end

		if level_id == "mia_1" and (self._id == 138758 or self._id == 138358 or self._id == 137958) then
			self._values.on_executed = {
				[1] = {
					["id"] = 138350,
					["delay"] = 0
				}
			}
		end

		if level_id == "crojob2" and (self._id == 131858 or self._id == 132158 or self._id == 132458 or self._id == 131558 or self._id == 133058 or self._id == 133658 or self._id == 133958 or self._id == 134558 or self._id == 131258 or self._id == 132758 or self._id == 134258) then
			self._values.on_executed = {
				[1] = {
					["id"] = 133954
				},
				[2] = {
					["id"] = 133968
				},
				[3] = {
					["id"] = 133973
				},
				[4] = {
					["id"] = 133980
				},
				[5] = {
					["id"] = 133985
				},
				[6] = {
					["id"] = 133915
				}
			}
		end

		--[[if level_id == "mex_cooking" and (self._id == 103641) then
			self._values.on_executed = {
				[1] = {
					["id"] = ,
					["delay"] = 0
				}
			}
		end--]]
	end
end