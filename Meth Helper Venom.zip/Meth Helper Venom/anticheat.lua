--anticheat
if NetworkMember then function NetworkMember.place_bag() return true end end
if GrenadeBase then function GrenadeBase.check_time_cheat() return true end end--Removes grenade's launcher silly delay. Crazy firerate enabled again (though it will work only on host side)
if ProjectileBase then function ProjectileBase.check_time_cheat() return true end end
function PlayerManager.verify_carry() return true end --Sometimes it blocks host from spawning bag, so it lobotomied
function PlayerManager.verify_equipment() return true end
function PlayerManager.verify_grenade() return true end
function PlayerManager.register_grenade() return true end
function PlayerManager.register_carry() return true end
function NetworkPeer.begin_ticket_session() return true end
function NetworkPeer.on_verify_ticket() end
function NetworkPeer.end_ticket_session() end
function NetworkPeer.change_ticket_callback() end
function NetworkPeer.verify_job() end --Who cares own peer dlc heist or no
function NetworkPeer.verify_character() end --Doesn't forces people to pay for Female character
function NetworkPeer.verify_bag() return true end
function NetworkPeer.verify_outfit() end --Who cares own peer some outfit or no, saves a little of cpu aswell
function NetworkPeer._verify_outfit_data() end
function NetworkPeer._verify_cheated_outfit() end
function NetworkPeer._verify_content() return true end
function NetworkPeer.tradable_verify_outfit() end
function NetworkPeer.on_verify_tradable_outfit() end