function is_playing()
	if not BaseNetworkHandler then 
		return false 
	end
	return BaseNetworkHandler._gamestate_filter.any_ingame_playing[ game_state_machine:last_queued_state_name() ]
end

if not is_playing() then 
	return
end

mission_table = {
	["crojob2"] = {
		{ text = "Авто Варка - ON/OFF", callback_func = function() dofile("mods/Meth Helper Venom/autocooker.lua") end },
		{ text = "Складировать - Помещать сумки сразу на спавн сброса - ON/OFF", callback_func = function() dofile("mods/Meth Helper Venom/autocooker secure.lua") end },
		{ text = "Больше Мета - варит дополнительную сумку - ON/OFF", callback_func = function() dofile("mods/Meth Helper Venom/autocooker add more.lua") end },
	},
	["alex_1"] = {
		{ text = "Авто Варка - ON/OFF", callback_func = function() dofile("mods/Meth Helper Venom/autocooker.lua") end },
		{ text = "Складировать - Помещать сумки сразу на спавн сброса - ON/OFF", callback_func = function() dofile("mods/Meth Helper Venom/autocooker secure.lua") end },
		{ text = "Больше Мета - варит дополнительную сумку - ON/OFF", callback_func = function() dofile("mods/Meth Helper Venom/autocooker add more.lua") end },
	},
	["rat"] = {
		{ text = "Авто Варка - ON/OFF", callback_func = function() dofile("mods/Meth Helper Venom/autocooker.lua") end },
		{ text = "Складировать - Помещать сумки сразу на спавн сброса - ON/OFF", callback_func = function() dofile("mods/Meth Helper Venom/autocooker secure.lua") end },
		{ text = "Больше Мета - варит дополнительную сумку - ON/OFF", callback_func = function() dofile("mods/Meth Helper Venom/autocooker add more.lua") end },
	},
	["mia_1"] = {
		{ text = "Авто Варка - ON/OFF", callback_func = function() dofile("mods/Meth Helper Venom/autocooker.lua") end },
		{ text = "Складировать - Помещать сумки сразу на спавн сброса - ON/OFF", callback_func = function() dofile("mods/Meth Helper Venom/autocooker secure.lua") end },
		{ text = "Больше Мета - варит дополнительную сумку - ON/OFF", callback_func = function() dofile("mods/Meth Helper Venom/autocooker add more.lua") end },
	},
	["mex_cooking"] = {
		{ text = "Авто Варка - ON/OFF", callback_func = function() dofile("mods/Meth Helper Venom/autocooker.lua") end },
		{ text = "Складировать - Помещать сумки сразу на спавн сброса - ON/OFF", callback_func = function() dofile("mods/Meth Helper Venom/autocooker secure.lua") end },
		{ text = "Больше Мета - варит дополнительную сумку - ON/OFF", callback_func = function() dofile("mods/Meth Helper Venom/autocooker add more.lua") end },
	},
	["cane"] = {
		{ text = "Авто Варка - ON/OFF", callback_func = function() dofile("mods/Meth Helper Venom/autocooker.lua") end },
		{ text = "Складировать - Помещать сумки сразу на спавн сброса - ON/OFF", callback_func = function() dofile("mods/Meth Helper Venom/autocooker secure.lua") end },
		{ text = "Больше Мета - варит дополнительную сумку - ON/OFF", callback_func = function() dofile("mods/Meth Helper Venom/autocooker add more.lua") end },
	},
}

function mission_menu()
	local dialog_data = {    
		title = "Меню Автоматической Варки Мета",
		text = "Выберите опцию",
		button_list = {}
	}
	
	local list = {
		managers.job:current_level_id(),
	}
	for _, absolute_list in pairs(list) do
		for _, mission_func in pairs(mission_table[absolute_list]) do
			table.insert(dialog_data.button_list, mission_func)
		end
	end

	table.insert(dialog_data.button_list, {})
	table.insert(dialog_data.button_list, { text = managers.localization:text("dialog_cancel"), focus_callback_func = function () end, cancel_button = true }) 
	managers.system_menu:show_buttons(dialog_data)
end
mission_menu()