function is_playing()
	if not BaseNetworkHandler then 
		return false 
	end
	return BaseNetworkHandler._gamestate_filter.any_ingame_playing[ game_state_machine:last_queued_state_name() ]
end

if not is_playing() then
	return
end

if global_toggle_meth then
	global_toggle_secure_meth = global_toggle_secure_meth or false
	if not global_toggle_secure_meth then
		secure_bagged = true
		managers.chat:feed_system_message(ChatManager.GAME, "Перемещение в сумок в машину - ON")
	else
		secure_bagged = false
		managers.chat:feed_system_message(ChatManager.GAME, "Перемещение в сумок в машину - OFF")
	end
	global_toggle_secure_meth = not global_toggle_secure_meth
else
	managers.chat:feed_system_message(ChatManager.GAME, "Сначала включите Автоварку")
end