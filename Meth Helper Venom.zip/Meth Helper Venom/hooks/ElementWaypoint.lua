function ElementWaypoint:on_executed(instigator)
	if not self._values.enabled then
		return
	end

	if self._values.only_on_instigator and instigator ~= managers.player:player_unit() then
		ElementWaypoint.super.on_executed(self, instigator)

		return
	end

	if managers.hud:get_waypoint_data(self._id) then -- Vanilla code below
		managers.hud:remove_waypoint(self._id)
	end

	ElementWaypoint.super.on_executed(self, instigator)
end