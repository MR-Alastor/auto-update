if not _upgradeValue then _upgradeValue = PlayerManager.upgrade_value end
function PlayerManager:upgrade_value( category, upgrade, default )
	
	if category == "player" and upgrade == "stamina_multiplier" then
		return 10000000000000000
	else
	
		return _upgradeValue(self, category, upgrade, default)
	end
end



