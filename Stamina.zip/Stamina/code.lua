if not _upgradeValue then _upgradeValue = PlayerManager.upgrade_value end
function PlayerManager:upgrade_value( category, upgrade, default )
	
	if category == "player" and upgrade == "pick_lock_speed_multiplier" then --отмычка
		return 0.1
	elseif category == "player" and upgrade == "pick_up_ammo_multiplier" then
		return 4.50
	elseif category == "player" and upgrade == "corpse_dispose_speed_multiplier" then -- ируп упак
		return 0.1
	elseif category == "player" and upgrade == "critical_hit_chance" then
		return 100000000000000000000000
	elseif category == "player" and upgrade == "alarm_pager_speed_multiplier" then
		return 0.1
	elseif category == "player" and upgrade == "stamina_multiplier" then
		return 10000000000000000
	elseif category == "player" and upgrade == "passive_dodge_chance" then
		return 10000000000000.1
	elseif category == "player" and upgrade == "run_dodge_chance" then
		return 0.55
	elseif category == "weapon" and upgrade == "armor_piercing_chance_silencer" then
		return 1
	elseif category == "player" and upgrade == "movement_speed_multiplier" then
		return 1000000000000000.10
	else
	
		return _upgradeValue(self, category, upgrade, default)
	end
end

 -- Weapon swap speed
PlayerStandard._get_swap_speed_multiplier = function(self) return 3.4 end

